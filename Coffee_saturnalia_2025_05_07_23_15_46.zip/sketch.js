let cars = [];
let planes = [];
let meteor;
let isNight = false;

function setup() {
  createCanvas(600, 400);

  for (let i = 0; i < 3; i++) {
    cars.push(new Car(random(width), height * 0.78));
    planes.push(new Plane(random(width), random(50, 100)));
  }

  meteor = new Meteor(random(width), -50);
}

function draw() {
  background(isNight ? 20 : 135, isNight ? 20 : 206, isNight ? 80 : 235);

  isNight ? drawStars() : drawClouds();
  drawField();
  drawRoad();
  drawTrees();
  drawCity();

  for (let car of cars) {
    car.move();
    car.display();
  }

  for (let plane of planes) {
    plane.move();
    plane.display();
  }

  meteor.move();
  meteor.display();
}

function mousePressed() {
  isNight = !isNight;
}

function drawClouds() {
  fill(255);
  for (let i = 50; i < width; i += 100) {
    ellipse(i, 50, 50, 30);
    ellipse(i + 20, 40, 60, 35);
    ellipse(i + 40, 50, 40, 30);
  }
}

function drawStars() {
  fill(255);
  for (let i = 0; i < 50; i++) {
    ellipse(random(width), random(height / 2), 3, 3);
  }
}

function drawField() {
  fill(isNight ? 20 : 34, isNight ? 100 : 139, isNight ? 20 : 34);
  rect(0, height / 2, width, height / 2);
}

function drawRoad() {
  fill(50);
  rect(0, height * 0.75, width, height / 8);
  stroke(255);
  for (let i = 20; i < width; i += 40) {
    line(i, height * 0.81, i + 20, height * 0.81);
  }
  noStroke();
}

function drawTrees() {
  for (let i = 40; i < 250; i += 70) {
    let treeHeight = random(40, 60);
    drawTree(i, height / 2, treeHeight);
  }
}

function drawTree(x, y, h) {
  fill(139, 69, 19);
  rect(x + 10, y, 20, h);
  fill(34, isNight ? 100 : 139, 34);
  ellipse(x + 20, y - h / 2, 60, 60);
}

function drawCity() {
  for (let i = 350; i < width; i += 60) {
    let buildingHeight = random(80, 120);
    drawBuilding(i, height / 2 - buildingHeight, buildingHeight);
  }
}

function drawBuilding(x, y, h) {
  fill(random(isNight ? 20 : 50, isNight ? 100 : 150));
  rect(x, y, 50, h);
  fill(isNight ? 255 : 200);
  for (let i = y + 10; i < y + h - 10; i += 20) {
    rect(x + 10, i, 10, 10);
    rect(x + 30, i, 10, 10);
  }
}

// Classe para carros
class Car {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.speed = random(2, 4);
  }

  move() {
    this.x += this.speed;
    if (this.x > width) {
      this.x = -40;
    }
  }

  display() {
    fill(random(200, 255), random(100, 200), random(100, 200));
    rect(this.x, this.y, 40, 20);
    fill(0);
    ellipse(this.x + 10, this.y + 20, 10, 10);
    ellipse(this.x + 30, this.y + 20, 10, 10);
  }
}

// Classe para aviões
class Plane {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.speed = random(1, 3);
  }

  move() {
    this.x += this.speed;
    if (this.x > width) {
      this.x = -50;
      this.y = random(50, 100);
    }
  }

  display() {
    fill(200);
    ellipse(this.x, this.y, 40, 15);
    fill(150);
    rect(this.x - 10, this.y - 5, 20, 3);
  }
}

// Classe para meteoros
class Meteor {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.speedX = random(-3, 3);
    this.speedY = random(4, 6);
  }

  move() {
    this.x += this.speedX;
    this.y += this.speedY;

    if (this.y > height) {
      this.x = random(width);
      this.y = -50;
      this.speedX = random(-3, 3);
      this.speedY = random(4, 6);
    }
  }

  display() {
    fill(255, 140, 0);
    ellipse(this.x, this.y, 30, 30);
    fill(255, 69, 0);
    ellipse(this.x - 10, this.y + 10, 20, 20);
    ellipse(this.x + 10, this.y + 10, 20, 20);
  }
}
